import base64
import gzip
import os
import subprocess

imports = './imports/'
exports = './exports/'
for file_name in os.listdir(imports):
    if os.path.isfile(os.path.join(imports, file_name)):
        with open(os.path.join(imports, file_name), 'rb') as file:
            file_data = file.read()
            compressed_data = gzip.compress(file_data)
            encoded_data = base64.b64encode(compressed_data)
            with open(os.path.join(exports, file_name.replace('.uasset', '.txt')), 'wb') as output_file:
                output_file.write(encoded_data)
            # Additional data processing can be added here

# Open destination directory
subprocess.Popen(['xdg-open', exports])