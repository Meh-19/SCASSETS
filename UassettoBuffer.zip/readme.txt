 __    __     ______     __  __    
/\ "-./  \   /\  ___\   /\ \_\ \   
\ \ \-./\ \  \ \  __\   \ \  __ \  
 \ \_\ \ \_\  \ \_____\  \ \_\ \_\ 
  \/_/  \/_/   \/_____/   \/_/\/_/ 
                                   
@Meh19 on discord: https://discord.com/users/990457338248962058

Swapping Connect v3 discord: https://discord.gg/swapping-connect-v3-maple-s-modding-community-1113899079039205497

Based on Jydn & Wslt's Buffer Creators

Credit to them for the originals, similar code.

 __  __     ______     __     __        ______   ______        __  __     ______     ______    
/\ \_\ \   /\  __ \   /\ \  _ \ \      /\__  _\ /\  __ \      /\ \/\ \   /\  ___\   /\  ___\   
\ \  __ \  \ \ \/\ \  \ \ \/ ".\ \     \/_/\ \/ \ \ \/\ \     \ \ \_\ \  \ \___  \  \ \  __\   
 \ \_\ \_\  \ \_____\  \ \__/".~\_\       \ \_\  \ \_____\     \ \_____\  \/\_____\  \ \_____\ 
  \/_/\/_/   \/_____/   \/_/   \/_/        \/_/   \/_____/      \/_____/   \/_____/   \/_____/ 
                                                                                               
- Put your .uasset into the 'imports' folder
- Click on 'script.py'
- Open the .txt file named accordingly in the 'exports' folder
- Ctrl + A and Ctrl + C
- Paste into '"Buffer": "<paste here>","

- You can also run 'deleteall.py' to delete all buffers and uassets from each folder.

 ______     ______     ______     __  __     __     ______     ______     __    __     ______     __   __     ______   ______    
/\  == \   /\  ___\   /\  __ \   /\ \/\ \   /\ \   /\  == \   /\  ___\   /\ "-./  \   /\  ___\   /\ "-.\ \   /\__  _\ /\  ___\   
\ \  __<   \ \  __\   \ \ \/\_\  \ \ \_\ \  \ \ \  \ \  __<   \ \  __\   \ \ \-./\ \  \ \  __\   \ \ \-.  \  \/_/\ \/ \ \___  \  
 \ \_\ \_\  \ \_____\  \ \___\_\  \ \_____\  \ \_\  \ \_\ \_\  \ \_____\  \ \_\ \ \_\  \ \_____\  \ \_\\"\_\    \ \_\  \/\_____\ 
  \/_/ /_/   \/_____/   \/___/_/   \/_____/   \/_/   \/_/ /_/   \/_____/   \/_/  \/_/   \/_____/   \/_/ \/_/     \/_/   \/_____/ 
                                                                                                                                 

- Have Node.js installed to run
- Textures over 2048x2048 or textures not multiples of 2 (512 x 1024, 1024 x 1024) are not compatible with Galaxy Swapper.
