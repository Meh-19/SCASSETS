import os

def delete_files_in_folders(folder_names):
    for folder_name in folder_names:
        if os.path.exists(folder_name):
            for file_name in os.listdir(folder_name):
                file_path = os.path.join(folder_name, file_name)
                try:
                    if os.path.isfile(file_path):
                        os.remove(file_path)
                        print(f"Deleted file: {file_path}")
                except Exception as e:
                    print(f"Error deleting {file_path}: {e}")

# Define folder names to delete files from
folders_to_delete_files = ["imports", "exports"]

# Delete files in specified folders
delete_files_in_folders(folders_to_delete_files)
